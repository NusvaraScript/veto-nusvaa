<?php $__env->startSection('title', 'Form Tambah - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-8">
        <h1 class="text-2xl font-bold mb-4">Form Tambah List</h1>
        <p class="text-gray-600">Isi formulir di bawah untuk menambahkan list baru.</p>

        <div class="my-4 border-2 border-black p-4">
            <form action="<?php echo e(route('vice.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label for="habit_name" class="block text-sm font-bold text-gray-700">Nama List</label>
                        <input type="text" name="habit_name" id="habit_name" placeholder="Masukkan Nama List . . ."
                            class="mt-1 w-full border-2 border-black p-1 hover:ring-red-500 hover:border-red-500">
                    </div>
                    <div>
                        <label for="severity" class="block text-sm font-bold text-gray-700">Keparahan</label>
                        <select name="severity" id="severity"
                            class="mt-1 w-full border-2 border-black p-1 hover:ring-red-500 hover:border-red-500">
                            <option value="" disabled selected>-- Pilih Keparahan --</option>
                            <option value="rendah">Rendah</option>
                            <option value="sedang">Sedang</option>
                            <option value="tinggi">Tinggi</option>
                        </select>
                    </div>
                    <div class="col-span-2">
                        <label for="description" class="block text-sm font-bold text-gray-700">Deskripsi</label>
                        <textarea name="description" id="description" placeholder="Masukkan Deskripsi Kebiasaan Buruk Kamu"
                            class="mt-1 w-full border-2 border-black p-1 hover:ring-red-500 hover:border-red-500"></textarea>
                    </div>
                    <div class="col-span-2">
                        <button type="submit" class="flex-1 text-black border-2 border-black px-4 py-1 font-bold uppercase bg-red-600 text-white hover:bg-red-700 hover:scale-105 active:scale-95 transition-all">
                            Simpan Kebiasaan
                        </button>
                        <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['route' => ''.e(route('vice.index')).'','variant' => 'outline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('vice.index')).'','variant' => 'outline']); ?>
                            Batal
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/pages/vice/create.blade.php ENDPATH**/ ?>