<?php $__env->startSection('title', 'Form Tambah Relapse - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section','data' => ['section' => 'Form Tambah Relapse']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Form Tambah Relapse']); ?>
        <p class="text-gray-600 mb-4">Catat kapan Anda kambuh dari kebiasaan buruk.</p>

        <div class="my-4 border-2 border-black p-4">
            <form action="<?php echo e(route('relapse.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 gap-4">
                    <div>
                        <label for="vices_id" class="block text-sm font-bold text-gray-700">Pilih Kebiasaan Buruk <span class="text-red-500">*</span></label>
                        <select name="vices_id" id="vices_id" required
                            class="mt-1 w-full border-2 border-black p-2 hover:ring-red-500 hover:border-red-500">
                            <option value="" disabled selected>-- Pilih Kebiasaan --</option>
                            <?php $__currentLoopData = $vices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vice['id']); ?>"><?php echo e($vice['label']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['vices_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="violation_date" class="block text-sm font-bold text-gray-700">Tanggal Kambuh <span class="text-red-500">*</span></label>
                        <input type="date" name="violation_date" id="violation_date" required
                            value="<?php echo e(old('violation_date', date('Y-m-d'))); ?>"
                            class="mt-1 w-full border-2 border-black p-2 hover:ring-red-500 hover:border-red-500">
                        <?php $__errorArgs = ['violation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="excuse" class="block text-sm font-bold text-gray-700">Alasan / Excuse</label>
                        <textarea name="excuse" id="excuse" placeholder="Tuliskan alasan atau catatan..."
                            class="mt-1 w-full border-2 border-black p-2 hover:ring-red-500 hover:border-red-500 h-32"><?php echo e(old('excuse')); ?></textarea>
                        <?php $__errorArgs = ['excuse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="flex-1 text-black border-2 border-black px-4 py-1 font-bold uppercase bg-red-600 text-white hover:bg-red-700 hover:scale-105 active:scale-95 transition-all">
                            Simpan Relapse
                        </button>
                        <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['route' => ''.e(route('relapse.index')).'','variant' => 'outline']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('relapse.index')).'','variant' => 'outline']); ?>
                            Batal
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                    </div>
                </div>
            </form>
        </div>

        
        <div class="mt-4 p-4 bg-yellow-50 border-2 border-yellow-500">
            <p class="text-sm text-yellow-800">
                <i class="fas fa-info-circle"></i> 
                <strong>Catatan:</strong> Ketika Anda menyimpan relapse, streak kebiasaan tersebut akan otomatis di-reset menjadi 0.
            </p>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $attributes = $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $component = $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/pages/relapse/create.blade.php ENDPATH**/ ?>