<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'route' => '#',
    'target' => '_self',
    'variant' => 'solid',
    'onclick' => '',
    'class' => ''
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'route' => '#',
    'target' => '_self',
    'variant' => 'solid',
    'onclick' => '',
    'class' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $button = match($variant) {
        'solid' => 'inline-block bg-red-600 text-white border-2 border-black px-2 py-1 font-bold uppercase hover:bg-white hover:text-black hover:shadow-block hover:scale-105 active:scale-95 transition-all',
        'outline' => 'inline-block bg-white text-black border-2 border-black px-2 py-1 font-bold uppercase hover:bg-red-600 hover:text-white hover:shadow-block hover:scale-105 active:scale-95 transition-all',
        'ghost' => 'text-white underline decoration-transparent hover:decoration-white hover:scale-105 active:scale-95 transition-all',
        'danger' => 'font-bold uppercase px-2 py-1 bg-red-600 text-white border-2 border-black hover:bg-red-700 hover:scale-105 active:scale-95 transition-all',
        'warning' => 'inline-block bg-yellow-500 text-white border-2 border-black px-2 py-1 font-bold uppercase hover:bg-white hover:text-black hover:shadow-block hover:scale-105 active:scale-95 transition-all',
        default => 'leading-relaxed text-blue-500 hover:underline'
    };
?>

<a href="<?php echo e($route); ?>" target="<?php echo e($target); ?>" class="<?php echo e($button); ?> <?php echo e($class); ?>" onclick="<?php echo e($onclick); ?>">
    <?php echo e($slot); ?>

</a><?php /**PATH D:\Coding\veto-nusvaa\resources\views/components/button.blade.php ENDPATH**/ ?>