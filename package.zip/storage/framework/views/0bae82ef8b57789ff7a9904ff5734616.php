<?php $__env->startSection('title', 'Riwayat Relapse - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section','data' => ['section' => 'Riwayat Relapse']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Riwayat Relapse']); ?>
        
        
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h2 class="text-xl font-black uppercase italic tracking-tighter">Log Kekalahan</h2>
                <p class="text-[10px] font-bold text-gray-500 uppercase">Pelajari polanya agar tidak jatuh di lubang yang sama.</p>
            </div>
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['route' => ''.e(route('relapse.create')).'','class' => 'border-2 border-black bg-red-600 text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all py-2 text-xs uppercase font-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('relapse.create')).'','class' => 'border-2 border-black bg-red-600 text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all py-2 text-xs uppercase font-black']); ?>
                + Catat Relapse Baru
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </div>

        
        <div class="border-2 border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-gray-50 border-b-2 border-black">
                        <tr>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest w-16">No</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest">Kebiasaan</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest">Alasan / Excuse</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest text-right">Tanggal</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y-2 divide-black">
                        <?php $__empty_1 = true; $__currentLoopData = $relapses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relapse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-red-50 transition-colors">
                                <td class="p-4 text-xs font-bold"><?php echo e($relapses->firstItem() + $loop->index); ?></td>
                                <td class="p-4">
                                    <span class="text-xs font-black uppercase px-2 py-1 border border-black bg-white">
                                        <?php echo e($relapse->vice->habit_name ?? '-'); ?>

                                    </span>
                                </td>
                                <td class="p-4 text-xs font-medium text-gray-600 italic">
                                    "<?php echo e($relapse->excuse ?? 'Tanpa alasan/catatan.'); ?>"
                                </td>
                                <td class="p-4 text-right">
                                    <span class="text-[10px] font-black uppercase bg-black text-white px-2 py-1">
                                        <?php echo e(\Carbon\Carbon::parse($relapse->violation_date)->format('d / m / Y')); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="p-12 text-center">
                                    <p class="text-xs font-bold uppercase text-gray-400 italic">Bersih. Tidak ada data relapse yang tercatat.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="mt-6">
            <?php echo e($relapses->links()); ?>

        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $attributes = $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $component = $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/user/pages/relapse/index.blade.php ENDPATH**/ ?>