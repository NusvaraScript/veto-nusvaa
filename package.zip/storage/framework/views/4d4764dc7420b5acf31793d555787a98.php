<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin — VetoNusvaa'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="antialiased h-screen flex flex-col bg-gray-50 text-slate-900 font-sans">

    
    <nav class="bg-white border-b-4 border-black sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                
                
                <div class="flex items-center gap-3">
                    <button id="openAdminSidebar" class="md:hidden border-2 border-black px-2 py-1 bg-white hover:bg-gray-100 active:translate-y-0.5 transition-all">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-2 group">
                        <div class="bg-black text-white p-1 border-2 border-black shadow-[2px_2px_0px_0px_rgba(220,38,38,1)]">
                            <span class="text-xl font-black tracking-tighter italic px-1">VN.</span>
                        </div>
                        <div class="hidden sm:block">
                            <span class="text-lg font-black tracking-tight uppercase">Admin<span class="text-red-600">Panel</span></span>
                        </div>
                    </a>
                </div>

                
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-black uppercase text-xs py-2 px-4 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[1px] hover:translate-y-[1px] transition-all">
                        Keluar
                    </button>
                </form>
            </div>
        </div>
    </nav>

    
    <div class="flex flex-1 overflow-hidden relative">
        
        
        <div id="adminSidebarBackdrop" class="fixed inset-0 z-40 bg-black/50 hidden md:hidden opacity-0 transition-opacity duration-300"></div>
        
        
        <aside id="adminSidebar" class="fixed inset-y-0 left-0 z-50 w-64 border-r-2 border-black bg-white -translate-x-full transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:flex md:flex-col shadow-[4px_0px_0px_0px_rgba(0,0,0,1)] md:shadow-none">
            
            
            <div class="flex justify-end p-4 md:hidden">
                <button id="closeAdminSidebar" class="text-white border-2 border-black px-2 py-1 bg-red-600 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            
            <div class="flex-1 overflow-y-auto pt-4 md:pt-0">
                <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
            </div>
        </aside>

        
        <main class="flex-1 overflow-y-auto h-full bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                
                
                <?php if(session('success')): ?>
                    <div class="mb-6 p-4 bg-green-400 border-2 border-black font-bold uppercase text-xs shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                        <i class="fa-solid fa-check-circle mr-2"></i> <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sidebar = document.getElementById('adminSidebar');
        const backdrop = document.getElementById('adminSidebarBackdrop');
        const openBtn = document.getElementById('openAdminSidebar');
        const closeBtn = document.getElementById('closeAdminSidebar');

        const toggle = (open) => {
            if (open) {
                sidebar.classList.remove('-translate-x-full');
                backdrop.classList.remove('hidden');
                // Kecil delay untuk trigger transisi opacity
                setTimeout(() => backdrop.classList.add('opacity-100'), 10);
                document.body.classList.add('overflow-hidden'); // Kunci scroll saat menu buka
            } else {
                sidebar.classList.add('-translate-x-full');
                backdrop.classList.remove('opacity-100');
                document.body.classList.remove('overflow-hidden');
                setTimeout(() => backdrop.classList.add('hidden'), 300);
            }
        };

        openBtn?.addEventListener('click', () => toggle(true));
        closeBtn?.addEventListener('click', () => toggle(false));
        backdrop?.addEventListener('click', () => toggle(false));
    });
</script>

</body>
</html><?php /**PATH D:\Coding\veto-nusvaa\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>