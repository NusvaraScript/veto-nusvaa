<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'section' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'section' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<section class="py-6 sm:py-8">
    
    <?php if($section): ?>
        <div class="mb-6">
            <h1 class="text-2xl sm:text-3xl font-black italic tracking-tighter uppercase text-black">
                <?php echo e($section); ?><span class="text-red-600">.</span>
            </h1>
            
            <div class="mt-2 h-1 w-12 bg-black"></div>
        </div>
    <?php endif; ?>

    
    <div class="relative">
        <?php echo e($slot); ?>

    </div>
</section><?php /**PATH D:\Coding\veto-nusvaa\resources\views/components/section.blade.php ENDPATH**/ ?>