<?php $__env->startSection('title', 'Form Tambah Relapse - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section','data' => ['section' => 'Form Tambah Relapse']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Form Tambah Relapse']); ?>
        
        
        <div class="mb-6">
            <h2 class="text-xl font-black uppercase italic tracking-tighter">Catat Kekalahan</h2>
            <p class="text-xs font-bold text-gray-500 uppercase">Jujur pada diri sendiri adalah langkah pertama untuk bangkit.</p>
        </div>

        <div class="border-2 border-black bg-white p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <form action="<?php echo e(route('relapse.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 gap-6">
                    
                    
                    <div>
                        <label for="vices_id" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Pilih Kebiasaan Buruk <span class="text-red-600">*</span></label>
                        <select name="vices_id" id="vices_id" required
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-red-600 outline-none transition-all">
                            <option value="" disabled selected>-- PILIH DATA --</option>
                            <?php $__currentLoopData = $vices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vice['id']); ?>"><?php echo e(strtoupper($vice['label'])); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['vices_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="violation_date" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Tanggal Kambuh <span class="text-red-600">*</span></label>
                        <input type="date" name="violation_date" id="violation_date" required
                            value="<?php echo e(old('violation_date', date('Y-m-d'))); ?>"
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-red-600 outline-none transition-all">
                        <?php $__errorArgs = ['violation_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="excuse" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Alasan / Catatan (Opsional)</label>
                        <textarea name="excuse" id="excuse" placeholder="Kenapa ini terjadi? Catat situasinya agar tidak terulang..."
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-red-600 outline-none transition-all h-32 resize-none"><?php echo e(old('excuse')); ?></textarea>
                        <?php $__errorArgs = ['excuse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="bg-red-50 border-2 border-dashed border-red-600 p-3">
                        <p class="text-[10px] font-black text-red-600 uppercase leading-tight">
                            <i class="fas fa-exclamation-triangle mr-1"></i> Perhatian: Streak kebiasaan ini akan di-reset menjadi 0 hari segera setelah disimpan.
                        </p>
                    </div>

                    
                    <div class="flex flex-col sm:flex-row gap-3 pt-2">
                        <button type="submit" class="bg-red-600 text-white border-2 border-black px-6 py-3 font-black uppercase text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all">
                            Simpan Kekalahan
                        </button>
                        <a href="<?php echo e(route('relapse.index')); ?>" class="flex items-center justify-center bg-white text-black border-2 border-black px-6 py-3 font-black uppercase text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all text-center">
                            Batal
                        </a>
                    </div>
                </div>
            </form>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $attributes = $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $component = $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/user/pages/relapse/create.blade.php ENDPATH**/ ?>