<?php $__env->startSection('title', 'Form Edit - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section','data' => ['section' => 'Form Edit List']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Form Edit List']); ?>
        
        
        <div class="mb-6">
            <h2 class="text-xl font-black uppercase italic tracking-tighter text-black">Perbarui Kebiasaan</h2>
            <p class="text-xs font-bold text-gray-500 uppercase">Sesuaikan strategi atau deskripsi untuk hasil yang lebih baik.</p>
        </div>

        <div class="border-2 border-black bg-white p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <form action="<?php echo e(route('vice.update', $data->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    
                    <div class="col-span-1">
                        <label for="habit_name" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Nama Kebiasaan</label>
                        <input type="text" name="habit_name" id="habit_name" placeholder="NAMA KEBIASAAN..." required
                            value="<?php echo e(old('habit_name', $data->habit_name)); ?>"
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-black outline-none transition-all">
                        <?php $__errorArgs = ['habit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-span-1">
                        <label for="severity" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Level Keparahan</label>
                        <select name="severity" id="severity" required
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-black outline-none transition-all">
                            <option value="" disabled>-- PILIH LEVEL --</option>
                            <option value="rendah" <?php echo e(old($data->severity) == 'rendah' ? 'selected' : ''); ?>>RENDAH</option>
                            <option value="sedang" <?php echo e(old($data->severity) == 'sedang' ? 'selected' : ''); ?>>SEDANG</option>
                            <option value="tinggi" <?php echo e(old($data->severity) == 'tinggi' ? 'selected' : ''); ?>>TINGGI</option>
                        </select>
                        <?php $__errorArgs = ['severity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-span-1 md:col-span-2">
                        <label for="description" class="block text-[10px] font-black uppercase tracking-widest text-black mb-1">Deskripsi / Alasan Perubahan</label>
                        <textarea name="description" id="description" placeholder="Edit alasan atau deskripsi..."
                            class="w-full border-2 border-black p-3 bg-white font-bold text-sm focus:ring-0 focus:border-black outline-none transition-all h-32 resize-none"><?php echo e(old('description', $data->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 text-[10px] font-bold uppercase mt-1 italic"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-span-1 md:col-span-2 flex flex-col sm:flex-row gap-3 mt-2">
                        <button type="submit" 
                            class="bg-black text-white border-2 border-black px-8 py-3 font-black uppercase text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all">
                            Perbarui Data
                        </button>
                        <a href="<?php echo e(route('vice.index')); ?>" 
                            class="flex items-center justify-center bg-white text-black border-2 border-black px-8 py-3 font-black uppercase text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-none transition-all text-center">
                            Batal
                        </a>
                    </div>

                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $attributes = $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $component = $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/user/pages/vice/edit.blade.php ENDPATH**/ ?>