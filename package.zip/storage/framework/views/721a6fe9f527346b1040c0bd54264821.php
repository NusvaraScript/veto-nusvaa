<?php $__env->startSection('title', 'Manajemen - VetoNusvaa'); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section','data' => ['section' => 'Manajemen Kebiasaan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['section' => 'Manajemen Kebiasaan']); ?>
        
        
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h2 class="text-xl font-black uppercase italic tracking-tighter">Daftar Hitam</h2>
                <p class="text-[10px] font-bold text-gray-500 uppercase">Pantau tingkat keparahan dan pertahankan streak harianmu.</p>
            </div>
            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['route' => ''.e(route('vice.create')).'','class' => 'border-2 border-black bg-black text-white shadow-[2px_2px_0px_0px_rgba(220,38,38,1)] hover:shadow-none transition-all py-2 text-xs uppercase font-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('vice.create')).'','class' => 'border-2 border-black bg-black text-white shadow-[2px_2px_0px_0px_rgba(220,38,38,1)] hover:shadow-none transition-all py-2 text-xs uppercase font-black']); ?>
                + Tambah Kebiasaan
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
        </div>

        
        <div class="border-2 border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-gray-50 border-b-2 border-black">
                        <tr>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest w-16">No</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest">Kebiasaan</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest">Keparahan</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest text-center">Streak</th>
                            <th class="p-4 text-[10px] font-black uppercase tracking-widest text-right">Opsi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y-2 divide-black">
                        <?php $__empty_1 = true; $__currentLoopData = $vices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="p-4 text-xs font-bold"><?php echo e($vices->firstItem() + $loop->index); ?></td>
                                <td class="p-4">
                                    <p class="text-xs font-black uppercase"><?php echo e($vice->habit_name); ?></p>
                                    <p class="text-[9px] font-bold text-gray-400 uppercase mt-0.5"><?php echo e(Str::limit($vice->description, 40) ?: '-'); ?></p>
                                </td>
                                <td class="p-4">
                                    <span class="text-[9px] font-black uppercase border-2 border-black px-2 py-0.5 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] 
                                        <?php if($vice->severity == 'tinggi'): ?> bg-red-500 text-white
                                        <?php elseif($vice->severity == 'sedang'): ?> bg-yellow-400 text-black
                                        <?php else: ?> bg-green-500 text-white <?php endif; ?>">
                                        <?php echo e($vice->severity); ?>

                                    </span>
                                </td>
                                <td class="p-4 text-center">
                                    <span class="text-xs font-black"><?php echo e($vice->streak_days); ?> <span class="text-[9px] text-gray-400 uppercase">Hari</span></span>
                                </td>
                                <td class="p-4">
                                    <div class="flex justify-end gap-2">
                                        <a href="<?php echo e(route('vice.edit', $vice->id)); ?>" 
                                           class="border-2 border-black bg-white px-3 py-1 text-[9px] font-black uppercase shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[1px] hover:translate-y-[1px] transition-all">
                                            Edit
                                        </a>
                                        <button type="button" onclick="handleDelete(<?php echo e($vice->id); ?>)" 
                                           class="border-2 border-black bg-red-600 text-white px-3 py-1 text-[9px] font-black uppercase shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[1px] hover:translate-y-[1px] transition-all">
                                            Hapus
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="p-12 text-center">
                                    <p class="text-xs font-bold uppercase text-gray-400 italic">Daftar masih bersih. Tambahkan kebiasaan pertamamu.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="mt-6">
            <?php echo e($vices->links()); ?>

        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $attributes = $__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__attributesOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0)): ?>
<?php $component = $__componentOriginal785c8021fd1a6e19eb80cad4b837cda0; ?>
<?php unset($__componentOriginal785c8021fd1a6e19eb80cad4b837cda0); ?>
<?php endif; ?>

    
    <form id="deleteForm" action="" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function handleDelete(id) {
            document.getElementById('deleteForm').action = '/vice/' + id;
            if (confirm('Yakin ingin menghapus kebiasaan ini? Data streak dan riwayat akan ikut hilang.')) {
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\veto-nusvaa\resources\views/user/pages/vice/index.blade.php ENDPATH**/ ?>